var	MoviesTag = function ()
{
	positron.tag.QueryDatabaseTag.call (this);
	
	console.log ("MoviesTag()");
}
monohm.inherits (MoviesTag, positron.tag.QueryDatabaseTag);

// override to provide config from wherever
MoviesTag.prototype.getConfiguration = function (inElement)
{
	this.databaseName = "positron";
	this.storeName = "movies";
	this.searchString = inElement.getAttribute ("search");

	// don't confuse the query idb tag by providing an index if there is no search term
	if (this.searchString && this.searchString.length)
	{
		this.indexName = "name";
	}
	else
	{
		this.indexName = null;
	}
}

