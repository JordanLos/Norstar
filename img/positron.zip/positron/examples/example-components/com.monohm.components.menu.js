
monohm.provide ("hm.mono.components.menu");

hm.mono.components.Menu = function ()
{
	positron.View.call (this);
};
monohm.inherits (hm.mono.components.Menu, positron.View);

hm.mono.components.Menu.prototype.onDOMReady = function Menu_onDOMReady ()
{
	positron.View.prototype.onDOMReady.call (this);

	console.log ("Menu.onDOMReady()");
	
	this.element.innerHTML = "Haha! Menu's onDOMReady() filled this in!";
}

