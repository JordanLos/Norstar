/**
*
* @license
* Copyright � 2013 Jason Proctor.  All rights reserved.
*
**/

// CONSTRUCTOR

var	DistanceTag = function ()
{
	positron.tag.Tag.call (this);

	this.requiredAttributes.push ("from_latitude");
	this.requiredAttributes.push ("from_longitude");
	this.requiredAttributes.push ("to_latitude");
	this.requiredAttributes.push ("to_longitude");
};
monohm.inherits (DistanceTag, positron.tag.Tag);

DistanceTag.prototype.process = function (inElement, inContext, inTreeWalker)
{
	var	fromLatitude = positron.DOM.getFloatAttributeValue (inElement, "from_latitude") * (Math.PI / 180);
	var	fromLongitude = positron.DOM.getFloatAttributeValue (inElement, "from_longitude") * (Math.PI / 180);
	var	toLatitude = positron.DOM.getFloatAttributeValue (inElement, "to_latitude") * (Math.PI / 180);
	var	toLongitude = positron.DOM.getFloatAttributeValue (inElement, "to_longitude") * (Math.PI / 180);

	var	distance = new Object ();

	distance.m = Math.acos (Math.sin (fromLatitude) * Math.sin (toLatitude) + 
		Math.cos (fromLatitude) * Math.cos (toLatitude) *
		Math.cos (toLongitude - fromLongitude)) * 6371000;

	distance.km = distance.m / 1000;
	distance.mi = (distance.km * 5) / 8;
	distance.yards = distance.mi * 1760;
	distance.feet = distance.mi * 5280;

  return this.walkChildren (inElement, inContext, inTreeWalker, distance);
}

