var	Application = function (inCallback)
{
	positron.Application.call (this, inCallback);
}
monohm.inherits (Application, positron.Application);

Application.prototype.showBar = function (inEvent)
{
	gApplication.showView ("bar");
}
