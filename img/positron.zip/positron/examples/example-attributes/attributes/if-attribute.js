
monohm.provide ("IfAttribute");

var	IfAttribute = function ()
{
	positron.attribute.Attribute.call (this);
};
monohm.inherits (IfAttribute, positron.attribute.Attribute);

IfAttribute.prototype.process = function (inElement, inContext, inAttributeName, inAttributeNumber)
{
	var	success = false;
	var	expression = inElement.getAttribute (inAttributeName);
	
	if (expression && expression.length)
	{
		success = positron.Util.evaluateExpressionChain (expression);
	}

	if (!success)
	{
		positron.DOM.removeNode (inElement);
	}
	
	return true;
}

