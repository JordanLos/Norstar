
monohm.provide ("AddAttribute");

var	AddAttribute = function ()
{
	positron.attribute.Attribute.call (this);
};
monohm.inherits (AddAttribute, positron.attribute.Attribute);

AddAttribute.prototype.process = function (inElement, inContext, inAttributeName, inAttributeNumber)
{
	var	newContext = null;
	
	var	paramString = inElement.getAttribute (inAttributeName);
	
	if (paramString && paramString.length)
	{
		var	params = positron.Util.parseParams (paramString);
		
		for (var key in params)
		{
			if (newContext == null)
			{
				newContext = gApplication.makeContext (inContext);
			}
			
			newContext.put (key, params [key]);
		}
	}
	
	if (newContext)
	{
		return newContext;
	}
	else
	{
		return inContext;
	}
}

