/**
*
* @license
* Copyright © 2014 Jason Proctor.  All rights reserved.
*
**/

var	MenuView = function ()
{
	console.log ("MenuView()");
	
	positron.View.call (this);
};
monohm.inherits (MenuView, positron.View);

MenuView.prototype.onDOMReady = function ()
{
	console.log ("MenuView.onDOMReady()");
}

