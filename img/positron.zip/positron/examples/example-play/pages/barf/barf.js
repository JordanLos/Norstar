/**
*
* @license
* Copyright © 2013 Jason Proctor.  All rights reserved.
*
**/

var	BarfPage = function ()
{
	console.log ("BarfPage()");
	
	positron.Page.call (this);
};
monohm.inherits (BarfPage, positron.Page);

BarfPage.prototype.onDOMReady = function ()
{
	positron.Page.prototype.onDOMReady.call (this);
	
	console.log ("BarfPage.onDOMReady()");
}

