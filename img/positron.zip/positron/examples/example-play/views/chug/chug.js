/**
*
* @license
* Copyright © 2013 Jason Proctor.  All rights reserved.
*
**/

var	ChugView = function ()
{
	console.log ("ChugView()");
	
	positron.View.call (this);
};
monohm.inherits (ChugView, positron.View);

ChugView.prototype.wibble = function ()
{
	console.log ("ChugView.wibble()");
}

