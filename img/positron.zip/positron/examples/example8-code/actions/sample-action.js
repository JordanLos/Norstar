/**
*
* @license
* Copyright © 2013 Jason Proctor.  All rights reserved.
*
**/

monohm.provide ("SampleAction");

var	SampleAction = function ()
{
	positron.action.Action.call (this);
}
monohm.inherits (SampleAction, positron.action.Action);

// called when the associated trigger decides that its conditions are met
SampleAction.prototype.fire = function (inEvent)
{
	positron.action.Action.prototype.fire.call (this, inEvent);
	
	// do what your action does, here
	alert ("SampleAction fired!!");
};

