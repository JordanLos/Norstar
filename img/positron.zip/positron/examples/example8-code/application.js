
var	Application = function (inCallback)
{
	positron.Application.call (this, inCallback);
};

monohm.inherits (Application, positron.Application);

Application.prototype.onApplicationStartupComplete = function ()
{
	positron.Application.prototype.onApplicationStartupComplete.call (this);
}
